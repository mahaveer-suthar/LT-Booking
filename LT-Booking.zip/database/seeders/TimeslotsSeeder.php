<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Timeslots;
use Illuminate\Support\Carbon;

class TimeslotsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Timeslots::create([
            'start_time'=> date('H:i', strtotime('09:00:00')),
            'end_time'=> date('H:i', strtotime('11:00:00'))
        ]);
        Timeslots::create([
            'start_time'=> date('H:i', strtotime('11:30:00')),
            'end_time'=> date('H:i', strtotime('01:30:00'))
        ]);
        Timeslots::create([
            'start_time'=> date('H:i ', strtotime('02:00:00')),
            'end_time'=> date('H:i', strtotime('04:00:00'))
        ]);
        Timeslots::create([
            'start_time'=> date('H:i', strtotime('04:30:00')),
            'end_time'=> date('H:i', strtotime('06:30:00'))
        ]);
    }
}
