
<?php $__env->startSection('content'); ?>
    <h4>Timetable</h4>
    <div class="card">
        <div class="row p-2 m-0">
            <form class="needs-validation" novalidate action="<?php echo e(route('admin.upload')); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-row mb-2">
                    <label for="formFileMultiple" class="form-label">Upload File</label>
                    <input class="form-control" type="file" id="formFileMultiple" multiple name="excel_file" />
                </div>
                <div class="d-flex justify-content-end">
                    <button class="btn btn-primary" type="submit">Sumbit</button>
                </div>
            </form>
        </div>
    </div>
    

    <div class="card p-2">
        <div style="display: flex; justify-content: space-between;">
            <p style="color: red">Start date -: 21/03/2023</p>
            <p style="color: red">End date -: 21/05/2023</p>
        </div>
        <div class="table-responsive">
            <table id="table_id" cellspacing="0" width="100%"class="display">
                <thead>
                    <tr>
                        
                        <th scope="col">Day</th>
                        <th scope="col">Timeslots</th>
                        <th scope="col">Room</th>
                        <th scope="col">Course</th>
                        <th scope="col">Branch</th>
                        <th scope="col">Batch</th>
                        <th scope="col">Teacher</th>
                        <th scope="col">Designation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->day); ?></td>
                            
                            <td><?php echo e(date('g:i A', strtotime(App\Models\Timeslots::find($item->timeslots_id)->start_time))); ?>

                                -
                                <?php echo e(date('g:i A', strtotime(App\Models\Timeslots::find($item->timeslots_id)->end_time))); ?></td>
                            <td><?php echo e(App\Models\Lt_rooms::find($item->lt_id)->room_name); ?></td>
                            <td><?php echo e($item->course); ?></td>
                            <td><?php echo e($item->branch); ?></td>
                            <td><?php echo e($item->batch); ?></td>
                            <td><?php echo e($item->teacher_name); ?></td>
                            <td><?php echo e($item->designation); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jquery'); ?>
    <script>
        $(document).ready(function() {
            toastr.options.timeOut = 5000;
            <?php if(Session::has('success')): ?>
                toastr.success('Timetable Imported Successfully');
            <?php endif; ?>
            <?php if(Session::has('worng')): ?>
                toastr.info('Ohh! Somthing Went worng Please try again');
            <?php endif; ?>
            // $('#table_id').dataTable({
            //     "columnDefs": [{
            //         "width": "8%",
            //         "targets": 0,
            //         "className": "text-center"
            //     }],
            //     responsive: true,
            // });

        });
    </script>
    <script>
        $(document).ready(function() {
            // Setup - add a text input to each header cell
            $('#table_id thead th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text" class="form-control"  placeholder="' + title + '" />');
            });

            // DataTable
            var table = $('#table_id').DataTable({"ordering": false});

            // Apply the search
            table.columns().every(function() {
                var that = this;

                $('input', this.header()).on('keypress change', function(e) {
                    var keycode = e.which;
                    //launch search action only when enter is pressed
                    if (keycode == '13') {
                        console.log('enter key pressed !')
                        if (that.search() !== this.value) {
                            that
                                .search(this.value)
                                .draw();
                        }
                    }

                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Neologicx project\lt-booking\resources\views/admin/timetable.blade.php ENDPATH**/ ?>