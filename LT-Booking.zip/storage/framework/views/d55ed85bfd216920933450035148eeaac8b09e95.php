
<?php $__env->startSection('content'); ?>
    <h4>Available LTs</h4>
    <p>The following LT's are available for you to book in your selected date & timeslot</p>
    <table id="table_id" class="display">
        <thead>
            <tr>
                <th scope="col">Date</th>
                <th scope="col">Time</th>
                <th scope="col">LT Number</th>
                <th scope="col">Booking Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td scope="row"><?php echo e(date('d M Y', strtotime($rec->date))); ?></th>
                <td><?php echo e(date('g:i A',strtotime(App\Models\Timeslots::find($rec->timeslots_id)->start_time))); ?> To <?php echo e(date('g:i A',strtotime(App\Models\Timeslots::find($rec->timeslots_id)->end_time))); ?></td>
                <td scope="row"><?php echo e(App\Models\Lt_rooms::find($rec->lt_id)->room_name); ?></td>
                <td><?php switch( $rec->status ):
                    case ( "pending" ): ?>
                        <span  class="badge badge-pill badge-warning">In Process</span >
                    <?php break; ?>
                    <?php case ( "approved" ): ?>
                    <span class="badge badge-pill badge-success">Approved</span>
                    <?php break; ?>
                    <?php case ( "reject" ): ?>
                    <span class="badge badge-pill badge-danger">Rejected</span>
                    <?php break; ?>
                    <?php default: ?>
                    <span class="badge btn-danger btn-sm px-4">Not found</span>
                    <?php break; ?>
                <?php endswitch; ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jquery'); ?>
    <script>
        $(document).ready(function() {
            $('#table_id').DataTable({
                "order": [[ 0, "desc" ]], //or asc 
                "columnDefs" : [{"targets":0, "type":"date-eu"}],
        });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Neologicx project\lt-booking\resources\views/users/booking_status.blade.php ENDPATH**/ ?>