
<?php $__env->startSection('content'); ?>
    <h4>Available LTs</h4>
    <p>The following LT's are available for you to book in your selected date & timeslot</p>
    <table id="table_id" class="display">
        <thead>
            <tr>
                <th scope="col">Sr No</th>
                <th scope="col">LT Number</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$lt_room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td ><?php echo e($index+1); ?></td>
                <td ><?php echo e($lt_room->room_name); ?></td>
                <td><a onclick="applyRequest(<?php echo e($lt_room->id); ?>)" class="fxt-btn btn-sm px-4">Apply now</a></td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jquery'); ?>
    <script>
        $(document).ready(function() {
            $('#table_id').DataTable({
                // order: [
                //         [0, 'asc']
                //     ],
            });
        });


        function applyRequest(lt_id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You want to  send request ",
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Send Request'
            }).then((result) => {
                if (result.value) {
                    $.ajax('<?php echo e(route('user.applyRequest')); ?>', {
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: 'POST',
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>",
                            "lt_id":lt_id,
                            'date':"<?php echo e($user_data->date); ?>",
                            'timeslots_id':"<?php echo e($user_data->time); ?>"
                        },
                        success: function(data, status, xhr) {
                            console.log(data);
                            if (data.status == 200) {
                                Swal.fire({
                                    title: 'Applied successfully',
                                    icon: 'success',
                                    confirmButtonColor: '#3085d6',
                                    confirmButtonText: 'Ok'
                                }).then((result) => {
                                    if (result.value) {
                                        window.location.reload()
                                    }
                                })
                            }
                        },
                        error: function(jqXhr, textStatus, errorMessage) {

                        }
                    });

                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Neologicx project\lt-booking\resources\views/users/availableLts.blade.php ENDPATH**/ ?>