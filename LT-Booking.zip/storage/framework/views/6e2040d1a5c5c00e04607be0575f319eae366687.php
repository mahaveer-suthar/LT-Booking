<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">

    
    <link href="<?php echo e(asset('admin/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/custom.css')); ?>" rel="stylesheet">

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.css">

    
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.all.min.js"></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@10.10.1/dist/sweetalert2.min.css'>
</head>

<body>
    <div id="spinner-div" class="pt-5">
        <div class="spinner-border text-primary" role="status">
        </div>
      </div>
    <div class="wrapper">
        <nav id="sidebar" class="sidebar js-sidebar">
            <div class="sidebar-content js-simplebar">
                <a class="sidebar-brand" href="<?php echo e(route('admin.home')); ?>">
                    <span class="align-middle"><img style="width: 200px" src="<?php echo e(asset('img/logo-9.svg')); ?>"
                            alt="logo"></span>
                </a>

                <ul class="sidebar-nav">
                    <li class="sidebar-item">
                        <a style="text-decoration:none" class="sidebar-link" href="<?php echo e(route('admin.home')); ?>">
                            <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Booking
                                Request</span>
                        </a>
                    </li>
                    <li class="sidebar-item">
                        <a style="text-decoration:none" class="sidebar-link"
                            href="<?php echo e(route('admin.professor.index')); ?>">
                            <i class="align-middle" data-feather="user"></i> <span class="align-middle">Users</span>
                        </a>
                    </li>
                    
                    <li class="sidebar-item">
                        <a style="text-decoration:none" class="sidebar-link" href="<?php echo e(route('admin.timetable')); ?>">
                            <i class="align-middle" data-feather="grid"></i> <span class="align-middle">Timetable</span>
                        </a>
                    </li>

                </ul>
            </div>
        </nav>

        <div class="main">
            <nav class="navbar navbar-expand navbar-light navbar-bg">
                <a class="sidebar-toggle js-sidebar-toggle">
                    <i class="hamburger align-self-center"></i>
                </a>

                <div class="navbar-collapse collapse">
                    <ul class="navbar-nav navbar-align">
                        
                        <li class="nav-item dropdown">
                            <a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#"
                                data-bs-toggle="dropdown">
                                <i class="align-middle" data-feather="settings"></i>
                            </a>

                            <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#"
                                data-bs-toggle="dropdown">
                                <img src="<?php echo e(asset('admin/user.jpg')); ?>" class="avatar img-fluid rounded me-1"
                                    alt="admin" /> <span class="text-dark"><?php echo e(Auth::guard()->user()->name); ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a class="dropdown-item" href="<?php echo e(route('admin.home')); ?>"><i class="align-middle me-1"
                                        data-feather="user"></i> Profile</a>
                                <div class="dropdown-divider"></div>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                    style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>

                                <a class="dropdown-item"
                                    href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                                        class="align-middle me-1" data-feather="log-out"></i>Log out</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>

            <main class="content p-3">
                <?php echo $__env->yieldContent('content'); ?>

            </main>
        </div>
    </div>



    <script src=<?php echo e(asset('admin/js/app.js')); ?>></script>
    <script src=<?php echo e(asset('admin/js/master.js')); ?>></script>
    <script src=<?php echo e(asset('js/validator.min.js')); ?>></script>

    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.js"></script>
    <?php echo $__env->yieldContent('jquery'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Neologicx project\lt-booking\resources\views/layouts-admin/app.blade.php ENDPATH**/ ?>