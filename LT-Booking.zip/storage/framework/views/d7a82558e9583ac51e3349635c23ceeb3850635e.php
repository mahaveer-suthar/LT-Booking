
<?php $__env->startSection('content'); ?>
    <p style="color: #0e0c0c;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus at eius nisi ducimus commodi molestiae
        voluptates quis vero, maiores eos nam nobis ipsam id maxime unde enim, natus expedita. Aspernatur.</p>
    <p style="color: #0e0c0c;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus at eius nisi ducimus commodi molestiae
        voluptates quis vero, maiores eos nam nobis ipsam id maxime unde enim, natus expedita. Aspernatur.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Neologicx project\lt-booking\resources\views/users/home.blade.php ENDPATH**/ ?>