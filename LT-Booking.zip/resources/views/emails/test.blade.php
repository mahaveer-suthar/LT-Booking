<!DOCTYPE html>
<html>
<head>
<title>How to send mail using queue in Laravel 5.7? - ItSolutionStuff.com</title>
</head>
<body>
<center>
<h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
<a href="https://itsolutionstuff.com">Visit Our Website : ItSolutionStuff.com</a>
</h2>
</center>
<p>Hi, Sir</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<strong>Thank you Sir. :)</strong>
</body>
</html>