@extends('layouts.app')
@section('content')
    <p style="color: #0e0c0c;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus at eius nisi ducimus commodi molestiae
        voluptates quis vero, maiores eos nam nobis ipsam id maxime unde enim, natus expedita. Aspernatur.</p>
    <p style="color: #0e0c0c;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus at eius nisi ducimus commodi molestiae
        voluptates quis vero, maiores eos nam nobis ipsam id maxime unde enim, natus expedita. Aspernatur.</p>
@endsection
